
package iceone;


public class Bird extends Animal
{
    
    
    private int colour; 
    private String colourType;

        

    public int getColour() {
        return colour;
    }

    public void setColour(int colour)
    {
       // this.colour = colour;
        
        if (getColour() == 1) 
        {
            this.colour = colour;
            colourType = "Grey";
        }
        else if (getColour() == 2) 
        {
            this.colour = colour;
            colourType = "White";
        }
         else
        {
            this.colour = colour;
            colourType = "Black";
        }

    }

    public Bird(int colour, int IDtag, String species) {
        super(IDtag, species);
        this.colour = colour;
    }

    
    
    @Override
    public void inputData()
    {
        super.inputData();
        System.out.println("Enter the colour of the Bird by typing the following numbers: Grey = 1, White = 2 and Black = 3");
        colour = kb.nextInt();
        
    }
    
    @Override
    public void outputData()
    {
        super.outputData();
        System.out.println("The colour of its feathers are: "+colourType);
    }
    
    
}
