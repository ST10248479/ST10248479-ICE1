
package iceone;

import java.util.Scanner;


public class IceOne
{

    static Scanner kb = new Scanner(System.in);
    
    public static void main(String[] args) 
    {
       
        Bird brd = new Bird(1,0,"");
        Reptile rept = new Reptile(1,0,"");
        
        
        System.out.println("Please type '1' for Bird Species OR '2' for Reptile Species");
        int choice = kb.nextInt();
        //rather use type string
        
        
        if (choice == 1) //user ignoreEqualCase
        {
            System.out.println("Bird:");
            System.out.println("*****************");
            brd.inputData();
            brd.setSpecies("Bird");
            brd.setColour(brd.getColour());
            brd.setIDtag(brd.getIDtag());
            System.out.println("*****************");
            brd.outputData();
            
        }
        else if(choice == 2)
        {
            System.out.println("Reptile:");
            System.out.println("*****************");
            rept.inputData();
            rept.setSpecies("Reptile");
            rept.setBloodTemp(rept.getBloodTemp());
            rept.setIDtag(rept.getIDtag());
            System.out.println("*****************");
            rept.outputData();
        }
               
        
    }
    
}
