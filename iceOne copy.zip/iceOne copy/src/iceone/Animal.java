
package iceone;

import java.util.Scanner;

public class Animal 
{
    static Scanner kb = new Scanner (System.in);
    private int IDtag;
    private String species;

    public int getIDtag() 
    {
        return IDtag;
    }

    public void setIDtag(int IDtag) 
    {
        this.IDtag = IDtag;
    }

    public String getSpecies() 
    {
        return species;
    }

    public void setSpecies(String species) 
    {
        this.species = species;
    }

    //constructor
    public Animal(int IDtag, String species)
    {
        this.IDtag = IDtag;
        this.species = species;
    }
   
 
    public void inputData()
    {
        System.out.println("Please enter the ID Tag:");
        IDtag = kb.nextInt();
        System.out.println("Please enter the species the specied of the animal:");
        species = kb.next();
    }
    
    public void outputData()
    {
        System.out.println("ID Tag: "+IDtag);
        System.out.println("Species: "+species);
        
    }
}
