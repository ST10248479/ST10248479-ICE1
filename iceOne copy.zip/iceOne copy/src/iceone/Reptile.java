
package iceone;


public class Reptile extends Animal
{

   private double bloodTemp; 

    public Reptile(double bloodTemp, int IDtag, String species) {
        super(IDtag, species);
        this.bloodTemp = bloodTemp;
    }

   
    public double getBloodTemp() 
    {
        return bloodTemp; 
        
    }

    public void setBloodTemp(double bloodTemp)
    {
        this.bloodTemp = bloodTemp;
    }
    
   @Override
    public void inputData()
    {
        super.inputData();
        System.out.println("Enter the blood tempreture for the reptile:");
        bloodTemp = kb.nextDouble();
    }
    
   @Override
    public void outputData()
    {
        super.outputData();
        System.out.println("The blood tempreture for the reptile is "+bloodTemp);
    }
    
}
